package com.example.tecsup.departamentos;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class AdaptadorMarco extends BaseAdapter {
    Context c;
    List<String> datos;
    int layout;

    public AdaptadorMarco(Context c, List<String> datos, int layout) {
        this.c = c;
        this.datos = datos;
        this.layout = layout;
    }

    @Override
    public int getCount() {
        return datos.size();
    }

    @Override
    public Object getItem(int position) {
        return datos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(c);
        View view = inflater.inflate(layout, null);
        TextView tv = view.findViewById(R.id.txt_spinner);
        tv.setText(datos.get(position));
        return view;
    }
}
