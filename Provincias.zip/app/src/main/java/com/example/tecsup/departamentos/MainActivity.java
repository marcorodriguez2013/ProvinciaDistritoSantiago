package com.example.tecsup.departamentos;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Spinner provincia;
    Spinner distrito;
    List<String> list_provincia;
    List<String> list_distrito;
    String[] array_provincia;
    String[] array_distrito;
    //ArrayAdapter adapter_provincia;
    //ArrayAdapter adapter_distrito;
    AdaptadorMarco adapter_provincia;
    AdaptadorMarco adapter_distrito;
    Button btn_mandar;
    TextView txt_dni;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        array_provincia = getResources().getStringArray(R.array.provincias);

        list_provincia = new ArrayList<>();
        list_distrito = new ArrayList<>();
        Collections.addAll(list_provincia, array_provincia);
       //adapter_provincia = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, list_provincia);
        adapter_provincia = new AdaptadorMarco(MainActivity.this,list_provincia,R.layout.layoutmarco);
        distrito = findViewById(R.id.distrito);
        provincia = findViewById(R.id.provincia);
        provincia.setAdapter(adapter_provincia);
        provincia.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(MainActivity.this, provincia.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                if (position == 0){
                    list_distrito.clear();
                }
                if (position == 1) {
                    array_distrito = getResources().getStringArray(R.array.distrito_arequipa);
                    list_distrito.clear();
                    Collections.addAll(list_distrito, array_distrito);
                }
                if (position == 2) {
                    array_distrito = getResources().getStringArray(R.array.distrito_camana);
                    list_distrito.clear();
                    Collections.addAll(list_distrito, array_distrito);
                }

                //adapter_distrito = new ArrayAdapter(MainActivity.this, R.layout.support_simple_spinner_dropdown_item, list_distrito);
                adapter_distrito = new AdaptadorMarco(MainActivity.this,list_distrito,R.layout.layoutmarco);
                distrito.setAdapter(adapter_distrito);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btn_mandar = findViewById(R.id.btn_mandar);
        txt_dni = findViewById(R.id.txt_dni);
        btn_mandar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                intent.putExtra("var_provincia", provincia.getSelectedItem().toString());
                intent.putExtra("var_distrito",distrito.getSelectedItem().toString());
                intent.putExtra("var_dni",txt_dni.getText().toString());
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }
}
