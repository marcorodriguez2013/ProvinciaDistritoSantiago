package com.example.tecsup.departamentos;

import android.support.v4.widget.AutoSizeableTextView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView txt_provincia;
    TextView txt_distrito;
    TextView txt_dni;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txt_provincia = findViewById(R.id.txt_provincia);
        txt_distrito = findViewById(R.id.txt_distrito);
        txt_dni = findViewById(R.id.txt_dni);
        txt_provincia.setText(txt_provincia.getText()+ getIntent().getStringExtra("var_provincia"));
        txt_distrito.setText(txt_distrito.getText() + getIntent().getStringExtra("var_distrito"));
        txt_dni.setText(txt_dni.getText() + getIntent().getStringExtra("var_dni"));
    }
}
